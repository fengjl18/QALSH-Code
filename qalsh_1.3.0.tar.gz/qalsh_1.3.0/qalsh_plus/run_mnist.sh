make
rm *.o

# Parameters of QALSH:
#    -alg  (integer)   options of algorithms (0 - 3)
#    -n    (integer)   cardinality of the dataset
#    -qn   (integer)   number of queries
#    -d    (integer)   dimensionality of the dataset
#    -B    (integer)   page size
#    -leaf (integer)   leaf size of kd-tree\n"
#    -l	   (integer)   drusilla select: l (number of projections)
#    -m    (integer)   drusilla select: m (number of candidates)
#    -t    (integer)   top-t results of sample set (top level)
#    -nb   (integer)   number of blocks to search (bottom level)
#    -p    (real)      lp-norm, where p in (0, 2]
#    -z    (real)      symmetric factor of p-stable distr. zeta in [-1, 1]
#    -c    (real)      approximation ratio (c > 1)
#    -ds   (string)    file path of the dataset
#    -qs   (string)    file path of the query set
#    -ts   (string)    file path of the ground truth set
#    -df   (string)    data folder to store new format of data
#    -of   (string)    output folder to store info of qalsh
#
# The options of algorithms (-alg) are:
#    0 - Ground-Truth
#        Parameters: -alg 0 -n -qn -d -p -ds -qs -ts
#
#    1 - Two Level Indexing
#        Parameters: -alg 1 -n -d -B -leaf -l -m -p -z -c -ds -df -of
#
#    2 - Two Level c-k-ANN Search via QALSH+
#        Parameters: -alg 2 -qn -d -t -nb -p -qs -ts -df -of
#
# NOTE: Each parameter is required to be separated by one space


n=60000
qn=100
d=50
B=4096
leaf=4000
l=30
m=10
t=100
c=2.0
dname=Mnist

dPath=../data/${dname}/${dname}
dFolder=../data/${dname}/


### p = 0.5 ###
p=0.5
z=1.0
oFolder=../results/qalsh_plus/${dname}/L${p}/

./qalsh_plus -alg 0 -n ${n} -qn ${qn} -d ${d} -p ${p} -ds ${dPath}.ds -qs ${dPath}.q -ts ${dPath}.gt${p}

./qalsh_plus -alg 1 -n ${n} -d ${d} -B $B -leaf ${leaf} -l ${l} -m ${m} -p ${p} -z ${z} -c ${c} -ds ${dPath}.ds -df ${dFolder} -of ${oFolder}

for nb in $(seq 2 10)
do 
   ./qalsh_plus -alg 2 -qn ${qn} -d ${d} -t ${t} -nb ${nb} -p ${p} -qs ${dPath}.q -ts ${dPath}.gt${p} -df ${dFolder} -of ${oFolder}
done


### p = 1.0 ###
p=1.0
z=0.0
oFolder=../results/qalsh_plus/${dname}/L${p}/

./qalsh_plus -alg 0 -n ${n} -qn ${qn} -d ${d} -p ${p} -ds ${dPath}.ds -qs ${dPath}.q -ts ${dPath}.gt${p}

./qalsh_plus -alg 1 -n ${n} -d ${d} -B $B -leaf ${leaf} -l ${l} -m ${m} -p ${p} -z ${z} -c ${c} -ds ${dPath}.ds -df ${dFolder} -of ${oFolder}

for nb in $(seq 2 10)
do 
   ./qalsh_plus -alg 2 -qn ${qn} -d ${d} -t ${t} -nb ${nb} -p ${p} -qs ${dPath}.q -ts ${dPath}.gt${p} -df ${dFolder} -of ${oFolder}
done


### p = 2.0 ###
p=2.0
z=0.0
oFolder=../results/qalsh_plus/${dname}/L${p}/

./qalsh_plus -alg 0 -n ${n} -qn ${qn} -d ${d} -p ${p} -ds ${dPath}.ds -qs ${dPath}.q -ts ${dPath}.gt${p}

./qalsh_plus -alg 1 -n ${n} -d ${d} -B $B -leaf ${leaf} -l ${l} -m ${m} -p ${p} -z ${z} -c ${c} -ds ${dPath}.ds -df ${dFolder} -of ${oFolder}

for nb in $(seq 2 10)
do 
   ./qalsh_plus -alg 2 -qn ${qn} -d ${d} -t ${t} -nb ${nb} -p ${p} -qs ${dPath}.q -ts ${dPath}.gt${p} -df ${dFolder} -of ${oFolder}
done

