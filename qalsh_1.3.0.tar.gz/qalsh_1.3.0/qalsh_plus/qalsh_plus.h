#ifndef __QALSH_PLUS_H
#define __QALSH_PLUS_H

class QALSH;
class MinK_List;

// -----------------------------------------------------------------------------
struct Blocks {
	int n_pts_;
	int* index_;
	QALSH* lsh_;

	Blocks() {
		n_pts_ = -1;
		index_ = NULL;
		lsh_ = NULL;
	}

	~Blocks() {
		if (index_ != NULL) { delete[] index_; index_ = NULL; }
		if (lsh_ != NULL) { delete lsh_; lsh_ = NULL; }
	}
};

// -----------------------------------------------------------------------------
class QALSH_Plus {
public:
	QALSH_Plus();
	~QALSH_Plus();

	// -------------------------------------------------------------------------
	void init(						// init qalsh+		
		int n,							// number of data objects
		int d,							// dimensionality
		int B,							// page size
		float p,						// l_p distance
		float zeta,						// a parameter of p-stable distr.
		float ratio,					// approximation ratio
		char *output_folder);			// output folder

	// -------------------------------------------------------------------------
	int bulkload(					// bulkloading for each block
		vector<int> &block_size,		// size of each block
		int *object_id,					// object id with block order
		float **data);					// original data objects

	// -------------------------------------------------------------------------
	int restore(					// restore qalsh+
		char *output_folder);			// output folder

	// -------------------------------------------------------------------------
	int knn(						// knn seach via qalsh+	
		int top_k,						// top-k value
		float R,						// limited search radius
		vector<int> &block_order,		// block order for search
		float* query,					// input query
		char *data_folder,				// data folder
		MinK_List* list);				// top-k results

protected:
	int n_pts_;						// number of data objects
	int dim_;						// dimensionality
	int B_;							// page size

	float p_;						// l_p distance
	float zeta_;					// a parameter of p-stable distr.
	float ratio_;					// approximation ratio

	int num_blocks_;				// number of blocks 
	Blocks **blocks_;				// blocks
	float **data_;					// new order of data

	char path_[300];				// output path

	// -------------------------------------------------------------------------
	int  write_params();			// write parameters
	
	void display_params();			// display parameters

	int read_params();				// read parameters
};


#endif
