#include "headers.h"

// -----------------------------------------------------------------------------
int ground_truth(					// output the ground truth results
	int   n,							// number of data points
	int   qn,							// number of query points
	int   d,							// dimension of space
	float p,							// the p value of Lp norm, p in (0,2]
	char* data_set,						// address of data set
	char* query_set,					// address of query set
	char* truth_set)					// address of ground truth file
{
	clock_t startTime = (clock_t)-1;
	clock_t endTime = (clock_t)-1;

	int i, j;
	FILE* fp = NULL;

	// -------------------------------------------------------------------------
	//  Read data set and query set
	// -------------------------------------------------------------------------
	startTime = clock();
	g_memory += SIZEFLOAT * (n + qn) * d;
	if (check_mem()) return 1;

	float** data = new float*[n];
	for (i = 0; i < n; i++) data[i] = new float[d];
	if (read_set(n, d, data_set, data)) {
		error("Reading Dataset Error!\n", true);
	}

	float** query = new float*[qn];
	for (i = 0; i < qn; i++) query[i] = new float[d];
	if (read_set(qn, d, query_set, query) == 1) {
		error("Reading Query Set Error!\n", true);
	}
	endTime = clock();
	printf("Read Dataset and Query Set: %.6f Seconds\n\n",
		((float)endTime - startTime) / CLOCKS_PER_SEC);

	// -------------------------------------------------------------------------
	//  output ground truth results (using linear scan method)
	// -------------------------------------------------------------------------
	int maxk = MAXK;
	float dist = -1.0F;
	MinK_List* list = new MinK_List(maxk);
	g_memory += (SIZEFLOAT + SIZEINT) * maxk;

	fp = fopen(truth_set, "w");		// open output file
	if (!fp) {
		printf("I could not create %s.\n", truth_set);
		return 1;
	}

	fprintf(fp, "%d %d\n", qn, maxk);
	for (i = 0; i < qn; i++) {
		list->reset();
		for (j = 0; j < n; j++) {
			dist = calc_lp_dist(p, data[j], query[i], d);
			list->insert(dist, j);
		}

		fprintf(fp, "%d", i + 1);	// output Lp dist of k-nn points
		for (j = 0; j < maxk; j++) {
			fprintf(fp, " %f", list->ith_smallest_key(j));
		}
		fprintf(fp, "\n");
	}
	fclose(fp);						// close output file
	endTime = clock();
	printf("Generate Ground Truth: %.6f Seconds\n\n",
		((float)endTime - startTime) / CLOCKS_PER_SEC);

	// -------------------------------------------------------------------------
	//  Release space
	// -------------------------------------------------------------------------
	for (i = 0; i < n; i++) {
		delete[] data[i]; data[i] = NULL;
	}
	delete[] data; data = NULL;
	g_memory -= SIZEFLOAT * n * d;

	for (i = 0; i < qn; i++) {
		delete[] query[i]; query[i] = NULL;
	}
	delete[] query; query = NULL;
	g_memory -= SIZEFLOAT * qn * d;

	delete list; list = NULL;
	g_memory -= (SIZEFLOAT + SIZEINT) * maxk;

	//printf("memory = %.2f MB\n", (float) g_memory / (1024.0f * 1024.0f));
	return 0;
}

// -----------------------------------------------------------------------------
int two_level_indexing(				// two level indexing
	int n,								// number of data points
	int d,								// dimension of space
	int B,								// page size
	int kd_leaf_size,					// leaf size of kd-tree
	int l,								// number of proj (drusilla)
	int m,								// num of obj from each proj (drusilla)
	float p,							// the p value of Lp norm, p in (0,2]
	float zeta,							// symmetric factor of p-stable distr.
	float ratio,						// approximation ratio
	char* data_set,						// address of data set
	char* data_folder,					// folder to store new format of data
	char* output_folder)				// folder to store info of qalsh
{
	clock_t startTime = (clock_t)-1;
	clock_t endTime = (clock_t)-1;

	FILE* fp = NULL;
	char fname[300];

	// -------------------------------------------------------------------------
	//  Read data set
	// -------------------------------------------------------------------------
	startTime = clock();
	float** data = new float*[n];
	for (int i = 0; i < n; i++) data[i] = new float[d];
	if (read_set(n, d, data_set, data) == 1) {
		error("Reading Dataset Error!\n", true);
	}
	endTime = clock();
	printf("Read Dataset: %.6f Seconds\n\n",
		((float)endTime - startTime) / CLOCKS_PER_SEC);

	// -------------------------------------------------------------------------
	//  Write the data set in new format to disk
	// -------------------------------------------------------------------------
	startTime = clock();
	write_data_new_form(n, d, B, data, data_folder);
	endTime = clock();
	printf("Write Dataset in New Format: %.6f Seconds\n\n",
		((float) endTime - startTime) / CLOCKS_PER_SEC);
	
	// -------------------------------------------------------------------------
	//  Dividing the dataset into disjoin blocks using KD-Tree
	// -------------------------------------------------------------------------
	vector<int> block_size;
	int *object_id = new int[n];
	kd_tree(n, d, kd_leaf_size, data, output_folder, block_size, object_id);

	// -------------------------------------------------------------------------
	//  Drusilla Select
	// -------------------------------------------------------------------------
	startTime = clock();
	int num_blocks = (int) block_size.size();
	int sample_n = num_blocks * l * m;

	int *sample_id = new int[sample_n];
	float **sample_data = new float*[sample_n];
	for (int i = 0; i < sample_n; i++) sample_data[i] = new float[d];

	drusilla_select(d, l, m, block_size, object_id, data, output_folder, 
		sample_id, sample_data);

	endTime = clock();
	printf("Drusilla Select: %.6f Seconds\n\n",
		((float)endTime - startTime) / CLOCKS_PER_SEC);

	// -------------------------------------------------------------------------
	//  Build hash tables for the sample set
	// -------------------------------------------------------------------------
	startTime = clock();
	strcpy(fname, output_folder);
	strcat(fname, "sample_indices/");

	QALSH* lsh = new QALSH();
	lsh->init(sample_n, d, B, p, zeta, ratio, sample_id, fname);
	lsh->bulkload(sample_data);
	endTime = clock();

	float sample_index_time = ((float)endTime - startTime) / CLOCKS_PER_SEC;
	printf("\nSample Indexing Time: %.6f seconds\n\n", sample_index_time);

	// -------------------------------------------------------------------------
	//  Build hash tables for each block
	// -------------------------------------------------------------------------
	startTime = clock();
	strcpy(fname, output_folder);
	strcat(fname, "qalsh_plus.index");

	fp = fopen(fname, "w");
	if (!fp) {
		printf("I could not create %s.\n", fname);
		return 1;
	}

	QALSH_Plus* qalsh = new QALSH_Plus();
	qalsh->init(n, d, B, p, zeta, ratio, output_folder);
	qalsh->bulkload(block_size, object_id, data);
	endTime = clock();

	float divide_index_time = ((float)endTime - startTime) / CLOCKS_PER_SEC;
	printf("\nDivide Indexing Time: %.6f seconds\n\n", divide_index_time);

	fprintf(fp, "Sample: %.6f seconds\n", sample_index_time);
	fprintf(fp, "Divide: %.6f seconds\n", divide_index_time);
	fprintf(fp, "Total:  %.6f seconds\n", sample_index_time + divide_index_time);
	fclose(fp);

	// -------------------------------------------------------------------------
	//  release space
	// -------------------------------------------------------------------------
	for (int i = 0; i < n; i++) {
		delete[] data[i]; data[i] = NULL;
	}
	delete[] data; data = NULL;

	block_size.clear();
	delete[] object_id; object_id = NULL;

	delete[] sample_id; sample_id = NULL;
	for (int i = 0; i < sample_n; i++) {
		delete[] sample_data[i]; sample_data[i] = NULL;
	}
	delete[] sample_data; sample_data = NULL;

	delete lsh; lsh = NULL;
	delete qalsh; qalsh = NULL;
	
	return 0;
}

// -----------------------------------------------------------------------------
int two_level_lshknn(				// two level k-nn search via qalsh+
	int qn,								// number of query points
	int d,								// dimensionality
	int t,								// top-t ann of sample set
	int nb,								// number of blocks to search
	float p,							// the p value of Lp norm, p in (0,2]
	char* query_set,					// address of query set
	char* truth_set,					// address of ground truth set
	char* data_folder,					// folder to store new format of data
	char* output_folder)				// folder to store info of qalsh
{
	int ret = 0;
	int tmp = -1;
	int maxk = MAXK;
	FILE* fp = NULL;				// file pointer

	clock_t startTime = (clock_t)-1.0;
	clock_t endTime = (clock_t)-1.0;

	// -------------------------------------------------------------------------
	//  Read query set
	// -------------------------------------------------------------------------
	float** query = new float*[qn];
	for (int i = 0; i < qn; i++) query[i] = new float[d];
	if (read_set(qn, d, query_set, query)) {
		error("Reading Query Set Error!\n", true);
	}

	// -------------------------------------------------------------------------
	//  Read the ground truth file
	// -------------------------------------------------------------------------
	fp = fopen(truth_set, "r");
	if (!fp) {
		printf("Could not open the ground truth file.\n");
		return 1;
	}

	fscanf(fp, "%d %d\n", &qn, &maxk);
	float **R = new float*[qn];
	for (int i = 0; i < qn; i++) {
		R[i] = new float[maxk];

		fscanf(fp, "%d", &tmp);
		for (int j = 0; j < maxk; j++) {
			fscanf(fp, " %f", &R[i][j]);
		}
	}
	fclose(fp);

	// -------------------------------------------------------------------------
	//  initializa the parameters for k-nn search
	// -------------------------------------------------------------------------
	int kNNs[] = { 1, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 };
	int maxRound = 11;
	int top_k = -1;

	float allTime = -1.0f;
	float allRatio = -1.0f;
	float thisRatio = -1.0f;

	int thisIO = 0;
	int allIO = 0;
	
	MinK_List *sample_list = new MinK_List(t);
	vector<int> block_order;

	// -------------------------------------------------------------------------
	//  read block id from DrusillaSelect
	// -------------------------------------------------------------------------
	char fname[300];
	strcpy(fname, output_folder);
	strcat(fname, "DrusillaSelect.out");
	
	fp = fopen(fname, "r");
	if (!fp) {
		printf("I could not open %s.\n", fname);
		return 1;
	}

	int num_blocks = -1;
	int sample_n = -1;
	fscanf(fp, "%d %d\n", &num_blocks, &sample_n);
	
	unordered_map<int, int> block_id;
	int id = -1;
	int	block = -1;
	for (int j = 0; j < sample_n; j++) {
		fscanf(fp, "%d %d\n", &block, &id);
		block_id[id] = block;
	}
	fclose(fp);

	// -------------------------------------------------------------------------
	//  restore qalsh (for sample set) and qalsh+ 
	// -------------------------------------------------------------------------
	strcpy(fname, output_folder);
	strcat(fname, "sample_indices/");

	QALSH *lsh = new QALSH();
	if (lsh->restore(fname)) {
		error("Could not restore the samples of qalsh+\n", true);
	}

	QALSH_Plus *qalsh = new QALSH_Plus();
	if (qalsh->restore(output_folder)) {
		error("Could not restore the divideset of qalsh+\n", true);
	}

	// -------------------------------------------------------------------------
	//  K-nearest neighbor (k-nn) search via qalsh+
	// -------------------------------------------------------------------------
	char output_set[300];
	char str[30];
	sprintf(str, "qalsh_plus_nb=%d.out", nb);
	strcpy(output_set, output_folder);
	strcat(output_set, str);

	fp = fopen(output_set, "w");	// open output file
	if (!fp) {
		printf("Could not create the output file.\n");
		return 1;
	}

	printf("Two Level c-k-ANN Search via QALSH+: \n");
	printf("    Top-k\tRatio\t\tI/O\t\tTime (ms)\n");
	for (int num = 0; num < maxRound; num++) {
		startTime = clock();
		top_k = kNNs[num];
		MinK_List *list = new MinK_List(top_k);
		
		allRatio = 0.0f;
		allIO = 0;
		for (int i = 0; i < qn; i++) {
			// -----------------------------------------------------------------
			//  search on sample set
			// -----------------------------------------------------------------
			sample_list->reset();
			thisIO = lsh->knn(t, MAXREAL, query[i], data_folder, sample_list);
			
			int sample_top_k = top_k < t ? top_k - 1 : t - 1;
			float radius = sample_list->ith_smallest_key(sample_top_k);

			// -----------------------------------------------------------------
			//  determine block order for qalsh_plus search
			// -----------------------------------------------------------------
			block_order.clear();
			get_block_order(num_blocks, nb, sample_list, block_id, block_order);

			// -----------------------------------------------------------------
			//  search on each block
			// -----------------------------------------------------------------
			list->reset();
			thisIO += qalsh->knn(top_k, radius, block_order, query[i], 
				data_folder, list);
			
			// -----------------------------------------------------------------
			//  update statistics
			// -----------------------------------------------------------------
			thisRatio = 0.0f;
			for (int j = 0; j < top_k; j++) {
				thisRatio += list->ith_smallest_key(j) / R[i][j];
			}
			thisRatio /= top_k;
			allRatio += thisRatio;
			allIO += thisIO;

		}
		delete list; list = NULL;
		endTime = clock();
		allTime = ((float)endTime - startTime) / CLOCKS_PER_SEC;

		allRatio = allRatio / qn;
		allTime = (allTime * 1000.0f) / qn;
		allIO = (int)ceil((float)allIO / (float)qn);

		printf("    %3d\t\t%.4f\t\t%d\t\t%.2f\n", top_k, allRatio, allIO, allTime);
		fprintf(fp, "%d\t%f\t%d\t%f\n", top_k, allRatio, allIO, allTime);
	}
	printf("\n");
	fclose(fp);						// close output file

	// -------------------------------------------------------------------------
	//  Release space
	// -------------------------------------------------------------------------
	for (int i = 0; i < qn; i++) {
		delete[] query[i]; query[i] = NULL;
		delete[] R[i]; R[i] = NULL;
	}
	delete[] query; query = NULL;
	delete[] R; R = NULL;

	delete sample_list; sample_list = NULL;

	block_id.clear();
	block_order.clear();

	delete lsh; lsh = NULL;
	delete qalsh; qalsh = NULL;

	//printf("memory = %.2f MB\n", (float) g_memory / (1024.0f * 1024.0f));
	return 0;
}
