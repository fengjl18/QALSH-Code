#include "headers.h"

// -----------------------------------------------------------------------------
//	KD_Tree: structure for approximate and exact nearest neighbor search
// -----------------------------------------------------------------------------
KD_Tree::KD_Tree(						// constructor
	float** pts,							// point array
	int n,									// number of points
	int d,									// dimensionality
	int kd_leaf_size)						// leaf size of kd-tree
{
	pts_ = pts;							// init <pts>
	n_pts_ = n;							// init <n_pts>
	dim_ = d;							// init <dim>
	kd_leaf_size_ = kd_leaf_size;		// init <kd_leaf_size>

	pidx_ = new int[n_pts_];			// init <pidx>
	for (int i = 0; i < n_pts_; i++) {
		pidx_[i] = i;
	}

	KD_Rect bnd_box(dim_);
	calc_encl_rect(bnd_box);

	bnd_box_low_ = new float[dim_];		// init <bnd_box_low_>
	bnd_box_high_ = new float[dim_];	// init <bnd_box_high_>
	for (int i = 0; i < dim_; i++) {
		bnd_box_low_[i] = bnd_box.low_[i];
		bnd_box_high_[i] = bnd_box.high_[i];
	}
										// init <root_>
	root_ = rkd_tree(pidx_, n_pts_, bnd_box);
}

// -----------------------------------------------------------------------------
void KD_Tree::calc_encl_rect(			// calc smallest enclosing rectangle
	KD_Rect& bnds)							// bounding box (return)
{
	for (int i = 0; i < dim_; i++) {
		float low_bnd = pts_[pidx_[0]][i];
		float high_bnd = pts_[pidx_[0]][i];

		for (int j = 1; j < n_pts_; j++) {	// update low and high bound
			float val = pts_[pidx_[j]][i];

			if (val < low_bnd) low_bnd = val;
			else if (val > high_bnd) high_bnd = val;
		}
		bnds.low_[i] = low_bnd;
		bnds.high_[i] = high_bnd;
	}
}

// -----------------------------------------------------------------------------
KD_Tree::~KD_Tree()						// destructor
{
	if (root_ != NULL) {
		delete root_; root_ = NULL;
	}

	if (pidx_ != NULL) {
		delete[] pidx_; pidx_ = NULL;
	}
	if (bnd_box_low_ != NULL || bnd_box_high_ != NULL) {
		delete[] bnd_box_low_; bnd_box_low_ = NULL;
		delete[] bnd_box_high_; bnd_box_high_ = NULL;
	}
}

// -----------------------------------------------------------------------------
KD_Node* KD_Tree::rkd_tree(				// recursive build kd-tree
	int* pidx,								// point index
	int n,									// number of points
	KD_Rect& bnd_box)						// bounding box for current node
{
	if (n <= kd_leaf_size_) {			// leaf node
		return new KD_Leaf(pts_, dim_, n, pidx);
	}
	else {								// split node
		int cut_dim;					// cutting dimension
		float cut_val;					// cutting value
		int num_low;					// number of lower side
		KD_Node* left;					// left child
		KD_Node* right;					// right child

										// make split
		sl_midpt_split(pidx, n, bnd_box, cut_dim, cut_val, num_low);
										// save bounds for cutting dimension
		float low_val = bnd_box.low_[cut_dim];
		float high_val = bnd_box.high_[cut_dim];

										// recursive build left son
		bnd_box.high_[cut_dim] = cut_val;// from pidx[0...num_low-1]
		left = rkd_tree(pidx, num_low, bnd_box);
		bnd_box.high_[cut_dim] = high_val;// restore bound

										// recursive build right son
		bnd_box.low_[cut_dim] = cut_val;// from pidx[num_low...n-1]
		right = rkd_tree(pidx + num_low, n - num_low, bnd_box);
		bnd_box.low_[cut_dim] = low_val;// restore bound

										// create new split node
		return new KD_Split(pts_, dim_, cut_dim, cut_val,
			low_val, high_val, left, right);
	}
}

// -----------------------------------------------------------------------------
void KD_Tree::sl_midpt_split(			// sliding midpoint split rule
	int* pidx,								// point index
	int n,									// number of points
	const KD_Rect& bnds,					// bounding rect for cell
	int& cut_dim,							// cutting dimension (return)
	float& cut_val,							// cutting value (return)
	int& num_low)							// num of pts on low side (return)
{
	float max_var = MINREAL;
	float cut_min = -1.0f;
	float cut_max = -1.0f;
	cut_val = -1.0f;
	cut_dim = -1;

	float mean, median, variance, min, max;
	for (int i = 0; i < dim_; i++) {
		calc_statistics(pidx, n, i, mean, median, variance, min, max);

		if (variance > max_var) {
			max_var = variance;
			cut_val = median;//mean; //
			cut_dim = i;
			cut_min = min;
			cut_max = max;
		}
	}

	int br1, br2;						// permute points accordingly
	plane_split(pidx, n, cut_dim, cut_val, br1, br2);

	//--------------------------------------------------------------------------
	//	on return:		pa[0..br1-1]   <  cut_val
	//					pa[br1..br2-1] == cut_val
	//					pa[br2..n-1]   >  cut_val
	//
	//	we can set num_low to any value in the range [br1..br2]
	//--------------------------------------------------------------------------
	if (cut_val < cut_min) num_low = 1;
	else if (cut_val > cut_max) num_low = n - 1;
	else if (br1 > n / 2) num_low = br1;
	else if (br2 < n / 2) num_low = br2;
	else num_low = n / 2;

	//	float max_spread = -1.0f;
	//	for (int i = 0; i < dim_; i++) {
	//        float spread = calc_spread(pidx, n, i);
	//
	//        if (spread > max_spread) {
	//            max_spread = spread;
	//            cut_dim = i;
	//        }
	//	}
	//    
	//    float min_val, max_val;
	//    cut_val = calc_mean(pidx, n, cut_dim, min_val, max_val);
	//    
	//	int br1, br2;					// permute points accordingly
	//	plane_split(pidx, n, cut_dim, cut_val, br1, br2);
	//
	//	//--------------------------------------------------------------------------
	//	//	on return:		pa[0..br1-1]   <  cut_val
	//	//					pa[br1..br2-1] == cut_val
	//	//					pa[br2..n-1]   >  cut_val
	//	//
	//	//	we can set num_low to any value in the range [br1..br2]
	//	//--------------------------------------------------------------------------
	//	if (cut_val < min_val) num_low = 1;
	//	else if (cut_val > max_val) num_low = n - 1;
	//	else if (br1 > n/2) num_low = br1;
	//	else if (br2 < n/2) num_low = br2;
	//	else num_low = n/2;
}

// -----------------------------------------------------------------------------
float KD_Tree::calc_mean(               // calc mean
	int *pidx,                              // point indices
	int n,                                  // number of points
	int d,                                  // dimension to check
	float &min,                             // min value (return)
	float &max)                             // max value (return)
{
	float mean = 0.0f;
	min = pts_[pidx[0]][d];
	max = pts_[pidx[0]][d];

	for (int i = 0; i < n; i++) {
		float val = pts_[pidx[i]][d];
		mean += pts_[pidx[i]][d];

		if (val < min) min = val;
		else if (val > max) max = val;
	}
	return mean / n;
}

// -----------------------------------------------------------------------------
float KD_Tree::calc_spread(				// calc point spread along dim
	int* pidx,								// point indices
	int n,									// number of points
	int d)									// dimension to check
{
	float min_val = pts_[pidx[0]][d];
	float max_val = pts_[pidx[0]][d];
	for (int i = 1; i < n; i++) {
		float val = pts_[pidx[i]][d];

		if (val < min_val) min_val = val;
		else if (val > max_val) max_val = val;
	}
	return max_val - min_val;
}

// -----------------------------------------------------------------------------
void KD_Tree::calc_minmax(				// calc min and max value along dim
	int* pidx,								// point indices
	int n,									// number of points
	int d,									// dimension to check
	float& min,								// min value (return)
	float& max)								// max value (return)
{
	min = pts_[pidx[0]][d];
	max = pts_[pidx[0]][d];
	for (int i = 1; i < n; i++) {
		float val = pts_[pidx[i]][d];

		if (val < min) min = val;
		else if (val > max) max = val;
	}
}

// -----------------------------------------------------------------------------
void KD_Tree::plane_split(				// split points by a plane
	int* pidx,								// point index
	int n,									// number of points
	int d,									// cutting dimension
	float cv,								// cutting value
	int& br1,								// 1st break (values < cv) (return)
	int& br2)								// 2nd break (values = cv) (return)
{
	int left = 0;
	int right = n - 1;
	for (;;) {							// partition pa[0..n-1] about cv
		while (left < n && pts_[pidx[left]][d] < cv) left++;
		while (right >= 0 && pts_[pidx[right]][d] >= cv) right--;
		if (left > right) break;

		SWAP(pidx[left], pidx[right]);	// swap point index
		left++; right--;
	}
	br1 = left;							// pa[0..br1-1] < cv <= pa[br1..n-1]

	right = n - 1;
	for (;;) {							// partition pa[br1..n-1] about cv
		while (left < n && pts_[pidx[left]][d] <= cv) left++;
		while (right >= 0 && pts_[pidx[right]][d] > cv) right--;
		if (left > right) break;

		SWAP(pidx[left], pidx[right]);	// swap point index
		left++; right--;
	}
	br2 = left;							// pa[br1..br2-1] = cv < pa[br2..n-1]
}

// -------------------------------------------------------------------------
void KD_Tree::calc_statistics(			// calc median and variance value
	int *pidx,								// point indices
	int n,									// number of points
	int d,									// dimension to check
	float &mean,                            // mean value (return)
	float &median,							// median value (return)
	float &variance,						// variance (return)
	float &min,								// min value (return)
	float &max)								// max value (return)
{
	// ---------------------------------------------------------------------
	//  calc mean, min, and max
	// ---------------------------------------------------------------------
	float *arr = new float[n];
	float val = pts_[pidx[0]][d];
	arr[0] = val;
	min = val;
	max = val;
	mean = val;
	for (int i = 1; i < n; i++) {
		val = pts_[pidx[i]][d];
		arr[i] = val;
		mean += val;

		if (val < min) min = val;
		else if (val > max) max = val;
	}
	mean /= n;

	// ---------------------------------------------------------------------
	//  calc median
	// ---------------------------------------------------------------------
	sort(arr, arr + n);
	if (n % 2 != 0) {
		median = arr[n / 2];
	}
	else {
		median = (arr[n / 2 - 1] + arr[n / 2]) / 2;
	}

	// ---------------------------------------------------------------------
	//  calc variance
	// ---------------------------------------------------------------------
	variance = 0.0f;
	for (int i = 0; i < n; i++) {
		float diff = pts_[pidx[i]][d] - mean;
		variance += diff * diff;
	}
	variance /= n;

	// ---------------------------------------------------------------------
	//  release space
	// ---------------------------------------------------------------------
	delete[] arr; arr = NULL;
}

// -----------------------------------------------------------------------------
void KD_Tree::search(					// top-k nn search
	float* query,							// query point
	int top_k,								// k-nn
	float ratio,							// approximation ratio
	MinK_List* list)						// top-k nn list
{
	if (top_k > n_pts_) {
		error("Requesting more near neighbors than data points", true);
	}

	ratio = POW(ratio);
	float box_dist = calc_box_dist(query, bnd_box_low_, bnd_box_high_, dim_);
										// kd-tree search
	root_->search(query, box_dist, ratio, list);
}

// -----------------------------------------------------------------------------
void KD_Tree::traversal(
	vector<int> &block_size,			// leaf size (return)
	int *object_id)						// object id with leaf order (return)
{
	for (int i = 0; i < n_pts_; i++) {
		object_id[i] = pidx_[i];
	}
	root_->traversal(block_size);
}

// -----------------------------------------------------------------------------
float KD_Tree::calc_box_dist(			// compute distance from point to box
	const float* query,						// query point
	const float* low,						// low point of box
	const float* high,						// high point of box
	int dim)								// dimensionality
{
	float dist = 0.0F;
	float tmp = 0.0F;					// only consider dist out of box
	for (int i = 0; i < dim; i++) {
		if (query[i] < low[i]) {
			tmp = low[i] - query[i];
			dist = SUM(dist, POW(tmp));
		}
		else if (query[i] > high[i]) {
			tmp = query[i] - high[i];
			dist = SUM(dist, POW(tmp));
		}
	}
	return dist;
}
