#ifndef __ANN_H
#define __ANN_H

// -----------------------------------------------------------------------------
int ground_truth(					// output ground truth (data in memory)
	int   n,							// number of data points
	int   qn,							// number of query points
	int   d,							// dimension of space
	float p,							// the p value of Lp norm, p in (0,2]
	char* data_set,						// address of data set
	char* query_set,					// address of query set
	char* truth_set);					// address of ground truth file

// -----------------------------------------------------------------------------
int two_level_indexing(				// two level indexing
	int n,								// number of data points
	int d,								// dimension of space
	int B,								// page size
	int kd_leaf_size,					// leaf size of kd-tree
	int l,								// number of proj (drusilla)
	int m,								// num of obj from each proj (drusilla)
	float p,							// the p value of Lp norm, p in (0,2]
	float zeta,							// symmetric factor of p-stable distr.
	float ratio,						// approximation ratio
	char* data_set,						// address of data set
	char* data_folder,					// folder to store new format of data
	char* output_folder);				// folder to store info of qalsh

// -----------------------------------------------------------------------------
int two_level_lshknn(				// two level k-nn search via qalsh+
	int qn,								// number of query points
	int d,								// dimensionality
	int t,								// top-t ann of sample set
	int nb,								// number of blocks to search
	float p,							// the p value of Lp norm, p in (0,2]
	char* query_set,					// address of query set
	char* truth_set,					// address of ground truth set
	char* data_folder,					// folder to store new format of data
	char* output_folder);				// folder to store info of qalsh

#endif
