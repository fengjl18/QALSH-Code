#include "headers.h"


// -----------------------------------------------------------------------------
QALSH_Plus::QALSH_Plus()			// constructor
{
	n_pts_ = -1;
	dim_ = -1;
	B_ = -1;

	p_ = -1.0f;
	zeta_ = -1.0f;
	ratio_ = -1.0f;

	num_blocks_ = -1;
	blocks_ = NULL;
	data_ = NULL;
}

// -----------------------------------------------------------------------------
QALSH_Plus::~QALSH_Plus()			// destructor
{
	if (blocks_ != NULL) {
		for (int i = 0; i < num_blocks_; i++) {
			delete blocks_[i]; blocks_[i] = NULL;
		}
		delete[] blocks_; blocks_ = NULL;
	}

	if (data_ != NULL) {
		for (int i = 0; i < n_pts_; i++) {
			delete[] data_[i]; data_[i] = NULL;
		}
		delete[] data_; data_ = NULL;
	}
}

// -----------------------------------------------------------------------------
void QALSH_Plus::init(				// init qalsh+		
	int n,								// number of data objects
	int d,								// dimensionality
	int B,								// page size
	float p,							// l_p distance
	float zeta,							// a parameter of p-stable distr
	float ratio,						// approximation ratio
	char *output_folder)				// output folder
{
	n_pts_ = n;
	dim_ = d;
	B_ = B;

	p_ = p;
	zeta_ = zeta;
	ratio_ = ratio;

	strcpy(path_, output_folder);
}

// -----------------------------------------------------------------------------
int QALSH_Plus::bulkload(			// bulkloading for each block
	vector<int> &block_size,			// size of each block
	int *object_id,						// object id with block order
	float **data)						// original data objects
{
	num_blocks_ = (int) block_size.size();

	data_ = new float*[n_pts_];
	for (int i = 0; i < n_pts_; i++) {
		data_[i] = new float[dim_];

		int id = object_id[i];
		for (int j = 0; j < dim_; j++) {
			data_[i][j] = data[id][j];
		}
	}
	
	Blocks *block = NULL;
	char data_path[300];
	char index_path[300];
	
	int start = 0;
	for (int i = 0; i < num_blocks_; i++) {
		int size = block_size[i];
		block = new Blocks();

		// ---------------------------------------------------------------------
		//  build hash tables for each block
		// ---------------------------------------------------------------------
		sprintf(index_path, "%s%s/%d/", path_, DIVIDE_INDEX, i);
		block->lsh_ = new QALSH();
		block->lsh_->init(size, dim_, B_, p_, zeta_, ratio_, 
			object_id + start, index_path);
		block->lsh_->bulkload(data_ + start);

		// ---------------------------------------------------------------------
		//  update info
		// ---------------------------------------------------------------------
		delete block; block = NULL;
		start += size;
	}

	// -------------------------------------------------------------------------
	//  Display parameters of QALSH+
	// -------------------------------------------------------------------------
	display_params();				// display parameters
	write_params();

	return 0;
}

// -----------------------------------------------------------------------------
int QALSH_Plus::write_params()		// write parameters
{
	char fname[300];
	sprintf(fname, "%sqalsh_plus.para", path_);

	FILE* fp = NULL;
	fp = fopen(fname, "w");
	if (!fp) {
		printf("I could not create %s.\n", fname);
		printf("Perhaps no such folder %s?\n", path_);
		return 1;
	}

	fprintf(fp, "n = %d\n", n_pts_);
	fprintf(fp, "d = %d\n", dim_);
	fprintf(fp, "B = %d\n", B_);
	fprintf(fp, "p = %f\n", p_);
	fprintf(fp, "zeta = %f\n", zeta_);
	fprintf(fp, "c = %f\n", ratio_);
	fprintf(fp, "K = %d\n", num_blocks_);

	fclose(fp);
	return 0;
}

// -----------------------------------------------------------------------------
void QALSH_Plus::display_params()	// display parameters
{
	printf("Parameters of QALSH+:\n");
	printf("    n = %d\n", n_pts_);
	printf("    d = %d\n", dim_);
	printf("    B = %d\n", B_);
	printf("    p = %.2f\n", p_);
	printf("    zeta = %.2f\n", zeta_);
	printf("    c = %.2f\n", ratio_);
	printf("    K = %d\n", num_blocks_);
	printf("    path = %s\n\n", path_);
}

// -----------------------------------------------------------------------------
int QALSH_Plus::restore(			// restore qalsh+
	char *output_folder)				// output folder
{
	char index_path[300];

	strcpy(path_, output_folder);
	read_params();

	blocks_ = new Blocks*[num_blocks_];
	for (int i = 0; i < num_blocks_; i++) {
		blocks_[i] = new Blocks();

		sprintf(index_path, "%s%s/%d/", path_, DIVIDE_INDEX, i);
		blocks_[i]->lsh_ = new QALSH();
		blocks_[i]->lsh_->restore(index_path);
	}
	return 0;
}

// -----------------------------------------------------------------------------
int QALSH_Plus::read_params()		// read parameters
{
	char fname[300];
	sprintf(fname, "%sqalsh_plus.para", path_);

	FILE* fp = NULL;
	fp = fopen(fname, "r");
	if (!fp) {
		printf("I could not open %s.\n", fname);
		return 1;
	}

	fscanf(fp, "n = %d\n", &n_pts_);
	fscanf(fp, "d = %d\n", &dim_);
	fscanf(fp, "B = %d\n", &B_);
	fscanf(fp, "p = %f\n", &p_);
	fscanf(fp, "zeta = %f\n", &zeta_);
	fscanf(fp, "c = %f\n", &ratio_);
	fscanf(fp, "K = %d\n", &num_blocks_);

	fclose(fp);
	return 0;
}

// -----------------------------------------------------------------------------
int QALSH_Plus::knn(				// knn search via qalsh+
	int top_k,							// top-k value
	float R,							// limited search radius
	vector<int> &block_order,			// block order for search
	float* query,						// input query
	char *data_folder,					// data folder
	MinK_List* list)					// top-k results
{
	float radius = R;
	int sum_io = 0;
	int size = (int) block_order.size();
	for (int i = 0; i < size; i++) {
		int id = block_order[i];
		sum_io += blocks_[id]->lsh_->knn(top_k, radius, query, data_folder, list);
		radius = list->max_key();
	}
	return sum_io;
}
