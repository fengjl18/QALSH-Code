./run_sift.sh
./run_gist.sh
./run_trevi.sh
./run_p53.sh

